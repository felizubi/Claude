<?php

defined( 'ABSPATH' ) || exit;

class GPLVault_Util {
	protected static $singleton = null;
	/**
	 * @var GPLVault_Settings_Manager $settings
	 */
	protected $settings;

	public static function instance() {
		if ( is_null( self::$singleton ) ) {
			self::$singleton = new self();
		}

		return self::$singleton;
	}

	private function __construct() {
		$this->settings = GPLVault_Settings_Manager::instance();
	}

	public function rename_plugins( $plugins ) {
		$gv_plugins = (array) $this->settings->get_available_plugins();

		if ( ! empty( $gv_plugins ) ) {
			foreach ( $plugins as $key => $plugin ) {
				if ( array_key_exists( $key, $gv_plugins ) && ! empty( $gv_plugins[ $key ]['short_name'] ) ) {
					$plugins[ $key ]['Name'] = $gv_plugins[ $key ]['short_name'];
				}
			}
		}
		return $plugins;
	}

	public function disable_woothemes_notice() {
		add_filter( 'woocommerce_helper_suppress_admin_notices', '__return_true' );
	}

	public static function is_gplvault_area() {
		$pages = array(
			GPLVault_Admin::SLUG_PLUGINS,
			GPLVault_Admin::SLUG_THEME,
			GPLVault_Admin::SLUG_SETTINGS,
		);
		$p_now = isset( $_REQUEST['page'] ) ? sanitize_text_field( $_REQUEST['page'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		return in_array( $p_now, $pages, true );
	}

	public function cleanup() {
		$main  = GPLVault();
		$admin = GPLVault_Admin::instance();

		remove_action( 'init', array( $this, 'disable_woothemes_notice' ) );

		remove_action( 'init', array( $main, 'update_schema' ) );
		remove_action( 'init', array( $main, 'gplvault_six_hours_cron' ) );
		remove_action( 'init', array( $main, 'load_initial_schema' ) );

		remove_action( 'gplvault_six_hours_cron', array( $main, 'update_schema' ) );

		remove_filter( 'all_plugins', array( $this, 'rename_plugins' ) );
		remove_filter( 'cron_schedules', array( $main, 'cron_schedules' ) );
	}

	public function inactive_status_notice() {
		include GV_UPDATER_STATIC_PATH . 'notices/notice-inactive.php';
	}
}
