<?php
/**
 * GPLVault Updater items upgrade manager class
 *
 * @since 4.0.0-beta
 * @author GPLVault support@gplvault.com
 */

defined( 'ABSPATH' ) || exit;

class GPLVault_Upgrade_Manager {

	private static $instance;


	private function __construct() {}

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			do_action( 'gv_upgrade_manager_loaded' );
		}

		return self::$instance;
	}

	public function init() {
		if ( gv_settings_manager()->license_is_activated() ) {
			add_filter( 'gv_ajax_bindings', array( $this, 'ajax_bindings' ) );
		}
	}

	public function ajax_bindings( $ajax_bindings ) {
		$ajax_bindings     = is_array( $ajax_bindings ) ? $ajax_bindings : array();
		$upgrader_bindings = array(
			'update_plugin' => array( self::instance(), 'update_plugins' ),
			'update_theme'  => array( self::instance(), 'update_themes' ),
		);

		return wp_parse_args( $upgrader_bindings, $ajax_bindings );
	}

	public function update_plugins( $request_params ) {
		$payload = $request_params['data'] ?? array();
		if ( empty( $payload['plugin'] ) || empty( $payload['product_id'] ) || empty( $payload['product_id'] ) ) {
			$error_data = array(
				'slug'         => sanitize_key( wp_unslash( $payload['slug'] ) ),
				'plugin'       => sanitize_text_field( wp_unslash( $payload['plugin'] ) ),
				'product_id'   => gv_clean( wp_unslash( $payload['product_id'] ) ),
				'errorCode'    => 'gv_no_plugin_specified',
				'errorMessage' => __( 'No plugin specified.', 'gplvault' ),
			);
			return new WP_Error(
				$error_data['errorCode'],
				$error_data['errorMessage'],
				$error_data
			);
		}

		$plugin     = plugin_basename( sanitize_text_field( wp_unslash( $payload['plugin'] ) ) );
		$product_id = gv_clean( wp_unslash( $payload['product_id'] ) );
		$slug       = sanitize_key( wp_unslash( $payload['slug'] ) );

		$status = array(
			'update'     => 'plugin',
			'plugin'     => sanitize_text_field( wp_unslash( $payload['plugin'] ) ),
			'slug'       => $slug,
			'product_id' => $product_id,
			'oldVersion' => '',
			'newVersion' => '',
		);

		if ( ! current_user_can( 'update_plugins' ) || 0 !== validate_file( $plugin ) ) {
			$status['errorCode']    = 'gv_invalid_file';
			$status['errorMessage'] = __( 'Sorry, you are not allowed to update plugins for this site.', 'gplvault' );
			return new WP_Error( $status['errorCode'], $status['errorMessage'], $status );
		}

		$plugin_data          = get_plugin_data( WP_PLUGIN_DIR . '/' . $plugin );
		$status['plugin']     = $plugin;
		$status['pluginName'] = $plugin_data['Name'];

		if ( $plugin_data['Version'] ) {
			$status['oldVersion'] = sprintf( __( 'Version %s', 'gplvault' ), $plugin_data['Version'] );
		}

		require_once GPLVault()->includes_path( '/upgrader/class-gplvault-ajax-upgrader-skin.php' );
		require_once GPLVault()->includes_path( '/upgrader/class-gplvault-plugin-upgrader.php' );

		GPLVault_Admin::gv_update_plugins();

		$skin     = new GPLVault_Ajax_Upgrader_Skin();
		$upgrader = new GPLVault_Plugin_Upgrader( $skin );
		$result   = $upgrader->bulk_upgrade( array( $plugin ) );

		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			$status['debug'] = $skin->get_upgrade_messages();
		}

		if ( is_wp_error( $skin->result ) ) {
			$status['errorCode']    = $skin->result->get_error_code();
			$status['errorMessage'] = $skin->result->get_error_message();
			return new WP_Error( $status['errorCode'], $status['errorMessage'], $status );
		} elseif ( $skin->get_errors()->has_errors() ) {
			$status['errorMessage'] = $skin->get_error_messages();
			return new WP_Error( 'gv_skin_error', $status['errorMessage'], $status );
		} elseif ( is_array( $result ) && ! empty( $result[ $plugin ] ) ) {

			if ( true === $result[ $plugin ] ) {
				$status['errorMessage'] = $upgrader->strings['up_to_date'];
				return new WP_Error( 'gv_up_to_date', $status['errorMessage'], $status );
			}

			$plugin_data = get_plugins( '/' . $result[ $plugin ]['destination_name'] );
			$plugin_data = reset( $plugin_data );

			if ( $plugin_data['Version'] ) {
				/* translators: %s: Plugin version. */
				$status['newVersion'] = sprintf( __( 'Version %s', 'gplvault' ), $plugin_data['Version'] );
			}

			return $status;
		} elseif ( false === $result ) {
			global $wp_filesystem;
			$status['errorCode']    = 'unable_to_connect_to_filesystem';
			$status['errorMessage'] = __( 'Unable to connect to the filesystem. Please confirm your credentials.', 'gplvault' );

			// Pass through the error from WP_Filesystem if one was raised.
			if ( $wp_filesystem instanceof WP_Filesystem_Base && is_wp_error( $wp_filesystem->errors ) && $wp_filesystem->errors->has_errors() ) {
				$status['errorMessage'] = esc_html( $wp_filesystem->errors->get_error_message() );
			}

			return new WP_Error( $status['errorCode'], $status['errorMessage'], $status );
		}

		// An unhandled error occurred.
		$status['errorCode']    = 'gv_unhandled_error';
		$status['errorMessage'] = __( 'Plugin update failed.', 'gplvault' );

		return new WP_Error( $status['errorCode'], $status['errorMessage'], $status );
	}

	public function update_themes( $request_params ) {
		return $request_params;
	}
}
