<?php

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/interfaces/class-gplvault-logger-interface.php';
require_once __DIR__ . '/interfaces/class-gplvault-log-handler-interface.php';

require_once __DIR__ . '/class-gplvault-log-levels.php';
require_once __DIR__ . '/class-gplvault-log-handler.php';
require_once __DIR__ . '/class-gplvault-logger.php';

require_once __DIR__ . '/handlers/class-gplvault-log-handler-file.php';
