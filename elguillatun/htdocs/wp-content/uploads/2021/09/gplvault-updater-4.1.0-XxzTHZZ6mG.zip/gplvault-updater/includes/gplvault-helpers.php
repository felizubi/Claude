<?php

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'gv_clean' ) ) {
	/**
	 * This function sanitizes input text field
	 *
	 * This function is copy of WooCommerce `wc_clean` function.
	 *
	 * @param $var
	 *
	 * @return array|string
	 */
	function gv_clean( $var ) {
		if ( is_array( $var ) ) {
			return array_map( 'gv_clean', $var );
		}

		$var = trim( $var );

		if ( is_numeric( $var ) ) {
			if ( strpos( $var, '.' ) === false ) { // definitely an integer value
				return (int) $var;
			}

			return (float) $var;
		}

		return is_scalar( $var ) ? sanitize_text_field( $var ) : $var;
	}
}

if ( ! function_exists( 'gv_generate_password' ) ) :
	function gv_generate_password( $length = 12, $special_chars = true, $extra_special_chars = false ) {
		if ( ! function_exists( 'wp_generate_password' ) ) {
			require_once ABSPATH . WPINC . '/pluggable.php';
		}

		return wp_generate_password( $length, $special_chars, $extra_special_chars );
	}
endif;

if ( ! function_exists( 'gv_print_r' ) ) :
	function gv_print_r( $expression, $return = false ) {
		$alternatives = array(
			array(
				'func' => 'print_r',
				'args' => array( $expression, true ),
			),
			array(
				'func' => 'var_export',
				'args' => array( $expression, true ),
			),
			array(
				'func' => 'json_encode',
				'args' => array( $expression ),
			),
			array(
				'func' => 'serialize',
				'args' => array( $expression ),
			),
		);

		$alternatives = apply_filters( 'gplvault_print_r_alternatives', $alternatives, $expression );

		foreach ( $alternatives as $alternative ) {
			if ( function_exists( $alternative['func'] ) ) {
				$res = call_user_func_array( $alternative['func'], $alternative['args'] );
				if ( $return ) {
					return $res;
				}

				echo $res; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				return true;
			}
		}

		return false;
	}
endif;


if ( ! function_exists( 'gv_take' ) ) {
	function gv_take( $payload, $keys ) {
		$accumulator = array();

		$payload_data = is_array( $payload ) ? $payload : ( is_object( $payload ) ? (array) $payload : array() );

		foreach ( $keys as $key ) {
			$accumulator[ $key ] = array_key_exists( $key, $payload_data ) ? $payload_data[ $key ] : null;
		}

		return $accumulator;
	}
}

if ( ! function_exists( 'gv_unslashit' ) ) {
	function gv_unslashit( $text ) {
		return trim( $text, '/\\' );
	}
}

if ( ! function_exists( 'gv_slashit' ) ) {
	function gv_slashit( $text ) {
		return '/' . gv_unslashit( $text ) . '/';
	}
}
