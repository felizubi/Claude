<?php

if ( ! class_exists( 'WP_Plugins_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-plugins-list-table.php';
}

class GPLVault_Plugins_List_Table extends WP_Plugins_List_Table {
	public function __construct( $args = array() ) {
		global $status, $page;

		parent::__construct(
			array(
				'plural' => 'gv-plugins',
				'screen' => isset( $args['screen'] ) ? $args['screen'] : null,
			)
		);

		$this->_args['plural'] = 'gv-plugins';

		$allowed_statuses = array( 'active', 'inactive', 'search', 'upgrade' );
		$status           = 'all'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		if ( isset( $_REQUEST['plugin_status'] ) && in_array( $_REQUEST['plugin_status'], $allowed_statuses, true ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$status = $_REQUEST['plugin_status']; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited, WordPress.Security.NonceVerification.Recommended
		}

		if ( isset( $_REQUEST['s'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$_SERVER['REQUEST_URI'] = add_query_arg( 's', wp_unslash( $_REQUEST['s'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		$page = $this->get_pagenum(); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
	}

	/**
	 * @return array
	 */
	protected function get_table_classes() {
		return array( 'widefat', $this->_args['plural'], 'gv-layout__table' );
	}

	/**
	 * @return bool
	 */
	public function ajax_user_can() {
		return current_user_can( 'activate_plugins' );
	}

	/**
	 * @global string $status
	 * @global array  $plugins
	 * @global array  $totals
	 * @global int    $page
	 * @global string $orderby
	 * @global string $order
	 * @global string $s
	 */
	public function prepare_items() {
		global $status, $plugins, $totals, $page, $orderby, $order, $s;

		wp_reset_vars( array( 'orderby', 'order' ) );
		$all_gv_plugins        = apply_filters( 'gv_all_plugins', GPLVault_Helper::wp_plugins() );
		$columns               = $this->get_columns(); // Get all necessary column information.
		$hidden                = array(); // No columns to hide, but we must set as an array.
		$sortable              = array(); // No reason to make sortable columns.
		$primary               = $this->get_primary_column_name(); // Column which has the row actions.
		$this->_column_headers = array( $columns, $hidden, $sortable, $primary ); // Get all necessary column headers.

		$plugins = array( // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
			'all'      => $all_gv_plugins,
			'search'   => array(),
			'active'   => array(),
			'inactive' => array(),
			'upgrade'  => array(),
		);

		$screen = $this->screen;

		if ( current_user_can( 'update_plugins' ) ) {
			$current = get_site_transient( GPLVault_Admin::UPDATES_KEY_PLUGINS );
			foreach ( (array) $plugins['all'] as $plugin_file => $plugin_data ) {
				if ( isset( $current->response[ $plugin_file ] ) ) {
					$plugins['all'][ $plugin_file ]['update'] = true; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
					$plugins['upgrade'][ $plugin_file ]       = $plugins['all'][ $plugin_file ]; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
				}
			}
		}

		if ( ! $screen->in_admin( 'network' ) ) {
			$show                = current_user_can( 'manage_network_plugins' );
			$show_network_active = apply_filters( 'show_network_active_plugins', $show );
		}

		$plugin_info = get_site_transient( 'gv_update_plugins' );

		foreach ( (array) $plugins['all'] as $plugin_file => $plugin_data ) {
			if ( isset( $plugin_info->response[ $plugin_file ] ) ) {
				$plugin_data = array_merge( (array) $plugin_info->response[ $plugin_file ], array( 'update-supported' => true ), $plugin_data );
			} elseif ( isset( $plugin_info->no_update[ $plugin_file ] ) ) {
				$plugin_data = array_merge( (array) $plugin_info->no_update[ $plugin_file ], array( 'update-supported' => true ), $plugin_data );
			} elseif ( empty( $plugin_data['update-supported'] ) ) {
				$plugin_data['update-supported'] = false;
			}

			$filter_payload = array(
				'id'            => $plugin_file,
				'slug'          => '',
				'plugin'        => $plugin_file,
				'new_version'   => '',
				'url'           => '',
				'package'       => '',
				'icons'         => array(),
				'banners'       => array(),
				'banners_rtl'   => array(),
				'tested'        => '',
				'requires_php'  => '',
				'compatibility' => new stdClass(),
			);

			$plugins['all'][ $plugin_file ] = $plugin_data; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
			if ( isset( $plugins['upgrade'][ $plugin_file ] ) ) {
				$plugins['upgrade'][ $plugin_file ] = $plugin_data; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
			}

			// Filter into individual sections.
			if ( is_multisite() && ! $screen->in_admin( 'network' ) && is_network_only_plugin( $plugin_file ) && ! is_plugin_active( $plugin_file ) ) {
				if ( $show_network_active ) {
					// On the non-network screen, show inactive network-only plugins if allowed.
					$plugins['inactive'][ $plugin_file ] = $plugin_data; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
				} else {
					// On the non-network screen, filter out network-only plugins as long as they're not individually active.
					unset( $plugins['all'][ $plugin_file ] );
				}
			} elseif ( ! $screen->in_admin( 'network' ) && is_plugin_active_for_network( $plugin_file ) ) {
				if ( $show_network_active ) {
					// On the non-network screen, show network-active plugins if allowed.
					$plugins['active'][ $plugin_file ] = $plugin_data; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
				} else {
					// On the non-network screen, filter out network-active plugins.
					unset( $plugins['all'][ $plugin_file ] );
				}
			} elseif ( ( ! $screen->in_admin( 'network' ) && is_plugin_active( $plugin_file ) )
				|| ( $screen->in_admin( 'network' ) && is_plugin_active_for_network( $plugin_file ) ) ) {
				// On the non-network screen, populate the active list with plugins that are individually activated.
				// On the network admin screen, populate the active list with plugins that are network-activated.
				$plugins['active'][ $plugin_file ] = $plugin_data; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited

				if ( ! $screen->in_admin( 'network' ) && is_plugin_paused( $plugin_file ) ) {
					$plugins['paused'][ $plugin_file ] = $plugin_data; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
				}
			} else {
				if ( isset( $recently_activated[ $plugin_file ] ) ) {
					// Populate the recently activated list with plugins that have been recently activated.
					$plugins['recently_activated'][ $plugin_file ] = $plugin_data; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
				}
				// Populate the inactive list with plugins that aren't activated.
				$plugins['inactive'][ $plugin_file ] = $plugin_data; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
			}
		}

		if ( strlen( $s ) ) {
			$status            = 'search'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
			$plugins['search'] = array_filter( $plugins['all'], array( $this, '_search_callback' ) ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		}

		$totals = array(); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		foreach ( $plugins as $type => $list ) {
			$totals[ $type ] = count( $list ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		}

		if ( empty( $plugins[ $status ] ) && ! in_array( $status, array( 'all', 'search' ), true ) ) {
			$status = 'all'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		}

		$gv_plugins  = gv_settings_manager()->get_available_plugins();
		$this->items = array();
		foreach ( $plugins[ $status ] as $plugin_file => $plugin_data ) {
			// Translate, don't apply markup, sanitize HTML.
			$gv_plugin_data = $gv_plugins[ $plugin_file ] ?? array();
			if ( ! empty( $gv_plugin_data ) ) {
				$this->items[ $plugin_file ]         = _get_plugin_data_markup_translate( $plugin_file, $plugin_data, false, true );
				$this->items[ $plugin_file ]['id']   = $gv_plugin_data['product_id'];
				$this->items[ $plugin_file ]['slug'] = $gv_plugin_data['slug'] ?? '';
			}
		}

		$total_this_page = $totals[ $status ];

		$js_plugins = array();
		foreach ( $plugins as $key => $list ) {
			$js_plugins[ $key ] = array_keys( $list );
		}

		wp_localize_script(
			'gv-updates',
			'_gvUpdatesItemCounts',
			array(
				'plugins' => $js_plugins,
				'totals'  => GPLVault_Helper::get_updates_data(),
			)
		);

		if ( ! $orderby ) {
			$orderby = 'Name'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		} else {
			$orderby = ucfirst( $orderby ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		}

		$order = strtoupper( $order ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited

		uasort( $this->items, array( $this, '_order_callback' ) );

		$plugins_per_page = $this->get_items_per_page( str_replace( '-', '_', $screen->id . '_per_page' ), 999 );

		$start = ( $page - 1 ) * $plugins_per_page;

		if ( $total_this_page > $plugins_per_page ) {
			$this->items = array_slice( $this->items, $start, $plugins_per_page );
		}

		$this->set_pagination_args(
			array(
				'total_items' => $total_this_page,
				'per_page'    => $plugins_per_page,
			)
		);
	}

	/**
	 * @global array $plugins
	 */
	public function no_items() {
		global $plugins;

		if ( ! empty( $_REQUEST['s'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$s = esc_html( wp_unslash( $_REQUEST['s'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

			/* translators: %s: Plugin search term. */
			printf( esc_html__( 'No plugins found for: %s.', 'gplvault' ), '<strong>' . esc_html( $s ) . '</strong>' );
		} elseif ( ! empty( $plugins['all'] ) ) {
			esc_html_e( 'No plugins found.', 'gplvault' );
		} else {
			esc_html_e( 'No plugins are currently available.', 'gplvault' );
		}
	}

	/**
	 * Displays the search box.
	 *
	 * @since 4.6.0
	 *
	 * @param string $text     The 'submit' button label.
	 * @param string $input_id ID attribute value for the search input field.
	 */
	public function search_box( $text, $input_id ) {
		if ( empty( $_REQUEST['s'] ) && ! $this->has_items() ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}

		$input_id = $input_id . '-search-input';

		if ( ! empty( $_REQUEST['orderby'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			echo '<input type="hidden" name="orderby" value="' . esc_attr( $_REQUEST['orderby'] ) . '" />'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}
		if ( ! empty( $_REQUEST['order'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			echo '<input type="hidden" name="order" value="' . esc_attr( $_REQUEST['order'] ) . '" />'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}
		?>
		<p class="search-box">
			<label class="screen-reader-text" for="<?php echo esc_attr( $input_id ); ?>"><?php echo esc_html( $text ); ?>:</label>
			<input type="search" id="<?php echo esc_attr( $input_id ); ?>" class="wp-filter-search" name="s" value="<?php _admin_search_query(); ?>" placeholder="<?php esc_attr_e( 'Search GPLVault plugins...', 'gplvault' ); ?>"/>
			<?php submit_button( $text, 'hide-if-js', '', false, array( 'id' => 'search-submit' ) ); ?>
		</p>
		<?php
	}

	/**
	 * @global string $status
	 * @return array
	 */
	public function get_columns() {
		global $status;

		$columns = array(
			'cb'          => ! in_array( $status, array( 'mustuse', 'dropins' ), true ) ? '<input type="checkbox" />' : '',
			'name'        => __( 'Plugin', 'gplvault' ),
			'description' => __( 'Description', 'gplvault' ),
			'has_update'  => __( 'Update', 'gplvault' ),
		);

		return $columns;
	}

	/**
	 * @return array
	 */
	protected function get_sortable_columns() {
		return array();
	}

	/**
	 * @global array $totals
	 * @global string $status
	 * @return array
	 */
	protected function get_views() {
		global $totals, $status;

		$status_links = array();
		foreach ( $totals as $type => $count ) {
			if ( ! $count ) {
				continue;
			}

			switch ( $type ) {
				case 'all':
					/* translators: %s: Number of plugins. */
					$text = _nx(
						'All <span class="count">(%s)</span>',
						'All <span class="count">(%s)</span>',
						$count,
						'plugins',
						'gplvault'
					);
					break;
				case 'active':
					/* translators: %s: Number of plugins. */
					$text = _n(
						'Active <span class="count">(%s)</span>',
						'Active <span class="count">(%s)</span>',
						$count,
						'gplvault'
					);
					break;
				case 'inactive':
					/* translators: %s: Number of plugins. */
					$text = _n(
						'Inactive <span class="count">(%s)</span>',
						'Inactive <span class="count">(%s)</span>',
						$count,
						'gplvault'
					);
					break;
				case 'upgrade':
					/* translators: %s: Number of plugins. */
					$text = _n(
						'Update Available <span class="count">(%s)</span>',
						'Update Available <span class="count">(%s)</span>',
						$count,
						'gplvault'
					);
					break;
			}

			if ( 'search' !== $type ) {
				$status_links[ $type ] = sprintf(
					"<a href='%s'%s>%s</a>",
					add_query_arg( 'plugin_status', $type, self_admin_url( 'admin.php?page=' . GPLVault_Admin::SLUG_PLUGINS, 'relative' ) ),
					( $type === $status ) ? ' class="current" aria-current="page"' : '',
					sprintf( $text, number_format_i18n( $count ) )
				);
			}
		}

		return $status_links;
	}

	/**
	 * @global string $s URL encoded search term.
	 *
	 * @param array $plugin
	 * @return bool
	 */
	public function _search_callback( $plugin ) {
		global $s;

		foreach ( $plugin as $value ) {
			if ( is_string( $value ) && false !== stripos( wp_strip_all_tags( $value ), urldecode( $s ) ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * @global string $orderby
	 * @global string $order
	 * @param array $plugin_a
	 * @param array $plugin_b
	 * @return int
	 */
	public function _order_callback( $plugin_a, $plugin_b ) {
		global $orderby, $order;

		$a = $plugin_a[ $orderby ];
		$b = $plugin_b[ $orderby ];

		if ( $a === $b ) {
			return 0;
		}

		if ( 'DESC' === $order ) {
			return strcasecmp( $b, $a );
		} else {
			return strcasecmp( $a, $b );
		}
	}

	/**
	 * @global string $status
	 * @return array
	 */
	protected function get_bulk_actions() {
		global $status;

		$actions = array();
		if ( ! is_multisite() || $this->screen->in_admin( 'network' ) ) {
			if ( current_user_can( 'update_plugins' ) ) {
				$actions['update-selected'] = __( 'Update', 'gplvault' );
			}
		}

		return $actions;
	}

	/**
	 * @global string $status
	 * @param string $which
	 */
	public function bulk_actions( $which = '' ) {
		global $status;

		if ( in_array( $status, array( 'mustuse', 'dropins' ), true ) ) {
			return;
		}

		if ( is_null( $this->_actions ) ) {
			$this->_actions = $this->get_bulk_actions();

			/**
			 * Filters the items in the bulk actions menu of the list table.
			 *
			 * The dynamic portion of the hook name, `$this->screen->id`, refers
			 * to the ID of the current screen.
			 *
			 * @since 3.1.0
			 * @since 5.6.0 A bulk action can now contain an array of options in order to create an optgroup.
			 *
			 * @param array $actions An array of the available bulk actions.
			 */
			$this->_actions = apply_filters( "bulk_actions-{$this->screen->id}", $this->_actions ); // phpcs:ignore WordPress.NamingConventions.ValidHookName.UseUnderscores

			$two = '';
		} else {
			$two = '2';
		}

		if ( empty( $this->_actions ) ) {
			return;
		}

		echo '<label for="bulk-action-selector-' . esc_attr( $which ) . '" class="screen-reader-text">' . esc_html__( 'Select bulk action', 'gplvault' ) . '</label>';
		echo '<select name="action' . esc_attr( $two ) . '" id="bulk-action-selector-' . esc_attr( $which ) . "\">\n";
		echo '<option value="-1">' . esc_html__( 'Bulk actions', 'gplvault' ) . "</option>\n";

		foreach ( $this->_actions as $key => $value ) {
			if ( is_array( $value ) ) {
				echo "\t" . '<optgroup label="' . esc_attr( $key ) . '">' . "\n";

				foreach ( $value as $name => $title ) {
					$class = ( 'edit' === $name ) ? ' class="hide-if-no-js"' : '';

					echo "\t\t" . '<option value="' . esc_attr( $name ) . '"' . $class . '>' . esc_html( $title ) . "</option>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				}
				echo "\t</optgroup>\n";
			} else {
				$class = ( 'edit' === $key ) ? ' class="hide-if-no-js"' : '';

				echo "\t" . '<option value="' . esc_attr( $key ) . '"' . $class . '>' . esc_html( $value ) . "</option>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		}

		echo "</select>\n";

		submit_button(
			__( 'Apply', 'gplvault' ),
			'action',
			'',
			false,
			array(
				'id'       => "doaction$two",
				'disabled' => true,
			)
		);
		echo "\n";
	}

	/**
	 * @global string $status
	 */
	public function display_rows() {
		global $status;

		foreach ( $this->items as $plugin_file => $plugin_data ) {
			$this->single_row( array( $plugin_file, $plugin_data ) );
		}
	}

	/**
	 * @global string $status
	 * @global int $page
	 * @global string $s
	 * @global array $totals
	 *
	 * @param array $item
	 */
	public function single_row( $item ) {
		global $status, $page, $s, $totals;
		static $plugin_id_attrs = array();

		list( $plugin_file, $plugin_data ) = $item;

		$plugin_name = $plugin_data['Name'];
		$description = ! empty( $plugin_data['Description'] ) ? wpautop( wp_kses_post( $plugin_data['Description'] ) ) : '';

		$plugin_slug    = isset( $plugin_data['slug'] ) ? $plugin_data['slug'] : sanitize_title( $plugin_data['Name'] );
		$product_id     = isset( $plugin_data['id'] ) ? $plugin_data['id'] : 0;
		$plugin_id_attr = $plugin_slug;

		// Ensure the ID attribute is unique.
		$suffix = 2;
		while ( in_array( $plugin_id_attr, $plugin_id_attrs, true ) ) {
			$plugin_id_attr = "$plugin_slug-$suffix";
			$suffix++;
		}

		$plugin_id_attrs[] = $plugin_id_attr;

		$context = $status;
		$screen  = $this->screen;

		// Pre-order.
		$actions = array(
			'update' => '',
		);

		// Do not restrict by default.
		$restrict_network_active = false;
		$restrict_network_only   = false;

		if ( $screen->in_admin( 'network' ) ) {
			$is_active = is_plugin_active_for_network( $plugin_file );
		} else {
			$is_active               = is_plugin_active( $plugin_file );
			$restrict_network_active = ( is_multisite() && is_plugin_active_for_network( $plugin_file ) );
			$restrict_network_only   = ( is_multisite() && is_network_only_plugin( $plugin_file ) && ! $is_active );
		}

		$actions = array_filter( $actions );

		$available_updates = get_site_transient( GPLVault_Admin::UPDATES_KEY_PLUGINS );
		$updates           = isset( $available_updates->response ) ? $available_updates->response : array();

		$requires_php   = isset( $plugin_data['requires_php'] ) ? $plugin_data['requires_php'] : null;
		$compatible_php = is_php_version_compatible( $requires_php );
		$class          = $is_active ? 'active' : 'inactive';
		$checkbox_id    = 'checkbox_' . md5( $plugin_file );

		if ( $restrict_network_active || $restrict_network_only || in_array( $status, array( 'mustuse', 'dropins' ), true ) || ! $compatible_php ) {
			$checkbox = '';
		} else {
			$checkbox = sprintf(
				'<label class="screen-reader-text" for="%1$s">%2$s</label>' .
				'<input type="checkbox" name="gv_bulk_plugins[]" value="%3$s" id="%1$s" />',
				$checkbox_id,
				/* translators: %s: Plugin name. */
				sprintf( __( 'Select %s', 'gplvault' ), $plugin_data['Name'] ),
				isset( $updates[ $plugin_file ] ) ? esc_attr( $plugin_file ) : ''
			);
		}

		if ( ! empty( $totals['upgrade'] ) && ! empty( $plugin_data['update'] ) ) {
			$class .= ' update has-update gv-item-update';
		}

		printf(
			'<tr class="%s" data-slug="%s" data-product="%d" data-plugin="%s" data-context="update_plugin">',
			esc_attr( $class ),
			esc_attr( $plugin_slug ),
			esc_attr( $product_id ),
			esc_attr( $plugin_file )
		);
		list( $columns, $hidden, $sortable, $primary ) = $this->get_column_info();

		foreach ( $columns as $column_name => $column_display_name ) {
			$extra_classes = '';
			if ( in_array( $column_name, $hidden, true ) ) {
				$extra_classes = ' hidden';
			}

			switch ( $column_name ) {
				case 'cb':
					echo "<th scope='row' class='check-column'>$checkbox</th>"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					break;
				case 'name':
					echo "<td class='plugin-title column-primary'><strong>$plugin_name</strong>"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo '</td>';
					break;
				case 'description':
					$classes = 'column-description desc';

					echo "<td class='$classes{$extra_classes}'>";  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo "<div class='plugin-description'>$description</div>"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo "<div class='gv-plugins-update-version'>";
					$plugin_meta = array();
					if ( ! empty( $plugin_data['Version'] ) ) {
						/* translators: %s: Plugin version number. */
						$plugin_meta[] = sprintf( __( 'Installed Version %s', 'gplvault' ), $plugin_data['Version'] );
					}
					if ( isset( $updates[ $plugin_file ] ) ) {
						/* translators: %s: Plugin new version number. */
						$plugin_meta[] = sprintf( __( 'Latest Version %s', 'gplvault' ), ( $updates[ $plugin_file ] )->new_version ?? 'Unknown' );

					}

					echo implode( ' | ', $plugin_meta ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo '</div>';
					echo '</td>';
					break;
				case 'has_update':
					$classes = 'column-gv-updates';
					echo "<td class='$classes{$extra_classes}'>"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					if ( isset( $updates[ $plugin_file ] ) ) :
						echo sprintf(
							'<button
							type="button"
							class="button button-secondary gv-button gv-trigger-update">%1$s</button>',
							esc_html__( 'Update', 'gplvault' )
						);
					endif;
					echo '</td>';

			}
		} // foreach $columns
		echo '</tr>';

	}

	protected function get_primary_column_name() {
		return 'name';
	}

	/**
	 * @return string
	 */
	public function current_action() {
		if ( isset( $_POST['clear-recent-list'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return 'clear-recent-list';
		}

		return parent::current_action();
	}
}
