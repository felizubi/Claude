<?php

defined( 'ABSPATH' ) || exit;

/**
 * Fired during plugin deactivation
 *
 * @since      1.0.0
 *
 * @package    GPLVault_Updater
 * @subpackage GPLVault_Updater/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    GPLVault_Updater
 * @subpackage GPLVault_Updater/includes
 * @author     GPL Vault <support@gplvault.com>
 */
class GPLVault_Updater_Deactivator {

	/**
	 * Run this method during plugin activation
	 *
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {
		foreach ( array(
			'gplvault_thrice_daily_cron',
			'gplvault_six_hours_cron',
			'gplvault_hourly_cron',
			'gplvault_two_hourly_cron',
			'gplvault_five_minutes_cron',
		) as $cron_action ) {
			wp_clear_scheduled_hook( $cron_action );
		}

		if ( ! class_exists( 'GPLVault_Settings_Manager', false ) ) {
			require_once GPLVault()->includes_path( '/settings/class-gplvault-settings-manager.php' );
		}

		if ( ! function_exists( 'gv_util' ) ) {
			require_once GPLVault()->includes_path( '/gplvault-functions.php' );
		}

		$settings_manager = GPLVault_Settings_Manager::instance();

		try {
			$deactivation_reponse = false;
			if ( $settings_manager->license_is_activated() ) {
				$deactivation_reponse = gv_api_manager()->set_initials()->deactivate();
			}
			if ( false !== $deactivation_reponse ) {
				GPLVault_Settings_Manager::instance()->remove_all_schema();
				GPLVault_Settings_Manager::instance()->deactivation();
			}
		} catch ( Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch
		}

		gv_util()->cleanup();
		wp_clean_plugins_cache();
		wp_clean_themes_cache();
	}

}
