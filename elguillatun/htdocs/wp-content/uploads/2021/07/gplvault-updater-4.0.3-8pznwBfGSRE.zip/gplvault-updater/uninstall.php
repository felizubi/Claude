<?php
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

require_once 'gplvault-updater.php';

/**
 * @var GPLVault_API_Manager $apiManager
 */
try {
	if ( GPLVault_Settings_Manager::instance()->has_api_settings() ) {
		gv_api_manager()->set_initials()->deactivate();
	}
} catch ( Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch
}

gv_util()->cleanup();
gv_settings_manager()->remove_api_key();
gv_settings_manager()->remove_initial();
