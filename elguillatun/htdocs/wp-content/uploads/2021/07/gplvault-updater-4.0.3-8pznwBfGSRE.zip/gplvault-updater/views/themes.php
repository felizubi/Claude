<?php
// phpcs:ignoreFile
defined( 'ABSPATH' ) || exit;

/** @var GPLVault_Settings_Manager $settings_manager    */
$license_is_active = $settings_manager->license_is_activated();
/** @var GPLVault_Admin $admin_manager */
GPLVault_Admin::gv_update_themes();
?>
	<div class="wrap gv-wrapper">
	<div class="gv-layout">
		<div class="gv-layout__primary">
			<div class="gv-layout__main gv-grids gv-grids__full">
				<?php if ( ! $license_is_active ) : ?>
					<div class="gv-admin-section">
						<div class="gv-admin-columns gv-grids gv-grids__columns-auto">
							<div class="gv-layout__columns">
								<div class="gv-card">
									<div class="gv-card__header">
										<h3 class="gv-card__title">
										<?php esc_html_e( 'Activate License', 'gplvault' ); ?></div>
									</h3>
									<div class="gv-card__body">
										<div class="gv-card__body-inner">
											<?php /* translator: %s: GPLVault Settings page URL */ ?>
											<h4>
											<?php
											printf(
												esc_html__( 'Please activate GPLVault Updater license to work with themes. Activate License from %s page.', 'gplvault' ),
												'<a href="' . esc_url( $admin_manager->admin_links( 'settings' ) ) . '">' . __( 'Settings', 'gplvault' ) . '</a>'
											);
											?>
													</h4>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php else : ?>
					<div class="gv-admin-section">
						<div class="gv-section-header">
							<h2 class="gv-section-header__title"><?php esc_html_e( 'License Activation', 'gplvault' ); ?></h2>
							<hr role="presentation">
						</div>
						<div class="gv-admin-columns gv-grids gv-grids__columns-auto">
							<div class="gv-layout__columns">
								<div class="gv-card">
									<div class="gv-card__header">
										<h3 class="gv-card__title"><?php esc_html_e( 'API Settings', 'gplvault' ); ?></h3>
									</div>
									<div class="gv-card__body">
										oh my god
										<p>Hello</p>
									</div>
								</div>
							</div>
							<div class="gv-layout__columns">
								<div class="gv-card">
									<div class="gv-card__header">
										<h3 class="gv-card__title"><?php esc_html_e( 'API Settings', 'gplvault' ); ?></h3>
									</div>
									<div class="gv-card__body">
									</div>
								</div>
							</div>
						</div>
					</div> <!-- .gv-admin-section -->
				<?php endif; ?>
				</diov> <!-- .gv-layout__main -->
			</div>
		</div>
	</div> <!-- .wrap -->

<?php
if ( ! function_exists( 'wp_print_request_filesystem_credentials_modal' ) ) {
	require_once ABSPATH . 'wp-admin/includes/file.php';
}
wp_print_request_filesystem_credentials_modal();
