<?php

defined( 'ABSPATH' ) || exit;

abstract class GPLVault_Api_Base {
	/**
	 * @var string $api_url
	 */
	protected $api_url;

	protected $response;

	protected $request_params;

	public function __construct( $params = null ) {
		$this->api_url = defined( 'GV_UPDATER_API_URL' ) && ! empty( GV_UPDATER_API_URL ) ? trailingslashit( GV_UPDATER_API_URL ) : 'https://www.gplvault.com/';

		$this->request_params = $params;
	}

	public static function of( $params = null ) {
		return new static( $params );
	}

	protected function raw_response() {
		return $this->response;
	}

	protected function response_status() {
		return wp_remote_retrieve_response_code( $this->response ) ?: null; // phpcs:ignore WordPress.PHP.DisallowShortTernary.Found
	}

	protected function response_message() {
		return wp_remote_retrieve_response_message( $this->response );
	}

	protected function response_headers() {
		return wp_remote_retrieve_headers( $this->response );
	}

	protected function response_header( $header ) {
		return wp_remote_retrieve_header( $this->response, $header );
	}

	public function request( $url, $args = array() ) {
		$defaults = array(
			'method'  => 'GET',
			'headers' => array(
				'User-Agent' => 'WordPress - GPLVault Updater ' . GV_UPDATER_VERSION,
			),
			'timeout' => 20,
		);

		$args = wp_parse_args( $args, $defaults );

		$debug_data = array(
			'request_url' => $url,
		);

		// Request to API URL
		$response = wp_remote_request( $url, $args );

		// Pluck response meta information
		$response_code    = wp_remote_retrieve_response_code( $response );
		$response_message = wp_remote_retrieve_response_message( $response );

		$debug_data['response_code']   = $response_code;
		$debug_data['response_cf_ray'] = wp_remote_retrieve_header( $response, 'cf-ray' );
		$debug_data['response_server'] = wp_remote_retrieve_header( $response, 'server' );

		// Check if the request failed to reach the API endpoint
		if ( ! empty( $response->errors ) ) {
			// TODO: show stored response errors as admin notices later on
			$notices = gv_settings_manager()->get_notices();
			if ( empty( $notices ) ) {
				$notices = array();
			}
			foreach ( $response->errors as $key => $error ) {
				$notices['http_error'][ $key ] = $error;
			}
			gv_settings_manager()->store_notices( $notices );
			if ( isset( $response->errors['http_request_failed'] ) ) {
				return new WP_Error( 'http_error', esc_html( current( $response->errors['http_request_failed'] ) ), $debug_data );
			}
		}

		if ( 200 !== $response_code ) {
			return ! empty( $response_message )
				? new WP_Error( $response_code, $response_message, $debug_data )
				: new WP_Error( $response_code, __( 'An unknown API error occurred.', 'gplvault' ), $debug_data );
		}

		$return = json_decode( wp_remote_retrieve_body( $response ), true );
		return $return ?? new WP_Error( 'api_error', __( 'An unknown API error occurred.', 'gplvault' ), $debug_data );
	}

	/**
	 * @param bool $is_array
	 * @return mixed
	 */
	protected function body( $is_array = true ) {
		return json_decode( wp_remote_retrieve_body( $this->response ), $is_array );
	}

	abstract public function ping();

	abstract public function status( $params = array());

	abstract public function activate( $params = array());

	abstract public function deactivate( $params = array());

	abstract public function download( $params = array());
}
