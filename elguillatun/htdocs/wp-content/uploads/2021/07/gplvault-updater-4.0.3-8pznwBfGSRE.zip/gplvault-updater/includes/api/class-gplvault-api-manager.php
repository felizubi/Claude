<?php

defined( 'ABSPATH' ) || exit;

class GPLVault_API_Manager {

	protected static $singleton;

	protected $api_url = '';

	protected $instance;
	protected $api_key;
	protected $product_id;
	protected $object;

	/**
	 * @var GPLVault_Settings_Manager
	 */
	protected $settings_manager;

	/**
	 * @var string $api_namespace
	 */
	protected $api_namespace = 'wp-json/gvsam/v2/';


	public static function instance( $singleton = false ) {
		if ( $singleton ) {
			if ( is_null( self::$singleton ) ) {
				self::$singleton = new self();
			}

			return self::$singleton;
		}

		return self::make();
	}

	protected function __construct() {
		$this->api_url = defined( 'GV_UPDATER_API_URL' ) ? trailingslashit( GV_UPDATER_API_URL ) : 'https://www.gplvault.com/';

		$this->load_dependencies();
		$this->set_initials();
	}

	public static function make() {
		return new self();
	}

	/**
	 * @global string $wp_version
	 * @return string
	 */
	public static function ua_string() {
		global $wp_version;
		require ABSPATH . WPINC . '/version.php';
		return 'WordPress/' . $wp_version . '; GPLVault Updater/' . GPLVault()->version() . '; ' . home_url( '/' );
	}

	public static function request_headers() {
		return array(
			'X-GV-Client'   => rawurlencode( home_url( '/' ) ),
			'X-GV-Version'  => GPLVault()->version(),
			'Cache-Control' => 'no-cache, must-revalidate, max-age=0',
		);
	}

	public function request( $url, $args = array() ) {
		$defaults = array(
			'method'     => 'GET',
			'user-agent' => static::ua_string(),
			'headers'    => static::request_headers(),
			'timeout'    => 20,
		);

		$args = wp_parse_args( $args, $defaults );

		$debug_data = array(
			'request_url' => $url,
		);

		// Request to API URL
		$response = wp_remote_request( $url, $args );

		// Pluck response meta information
		$response_code    = wp_remote_retrieve_response_code( $response );
		$response_message = wp_remote_retrieve_response_message( $response );

		$debug_data['response_code']   = $response_code;
		$debug_data['response_cf_ray'] = wp_remote_retrieve_header( $response, 'cf-ray' );
		$debug_data['response_server'] = wp_remote_retrieve_header( $response, 'server' );

		// Check if the request failed to reach the API endpoint
		if ( ! empty( $response->errors ) ) { // definitely WP_Error object
			// TODO: show stored response errors as admin notices later on
			$notices = gv_settings_manager()->get_notices();
			if ( empty( $notices ) ) {
				$notices = array();
			}
			foreach ( $response->errors as $key => $error ) {
				$notices['http_error'][ $key ] = $error;
			}
			gv_settings_manager()->store_notices( $notices );
			if ( isset( $response->errors['http_request_failed'] ) ) {
				$debug_data['response_error_code'] = 'http_request_error';
				return new WP_Error( 'http_request_error', esc_html( current( $response->errors['http_request_failed'] ) ), $debug_data );
			}

			$debug_data['response_error_code'] = $response->get_error_code();
			return new WP_Error( 'http_request_error', $response->get_error_message(), $debug_data );
		}

		$response_body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $response_code ) {
			$debug_data['response_error_code'] = $response_code;
			$debug_data['response_body']       = empty( $response_body ) ? array() : $response_body;

			return ! empty( $response_message )
				? new WP_Error( 'api_status_code', $response_message, $debug_data )
				: new WP_Error( 'api_status_code', __( 'An unknown API error occurred.', 'gplvault' ), $debug_data );
		}

		if ( empty( $response_body ) ) {
			return new WP_Error( 'api_error_empty', __( 'An unknown API error occurred.', 'gplvault' ), $debug_data );
		}

		if ( isset( $response_body['code'] ) ) {
			$debug_data['response_error_code']      = $response_body['code'];
			$debug_data['response_body']            = $response_body['data'];
			$debug_data['response_body']['success'] = $response_body['success'] ?? false;

			if ( '100' === $response_body['code'] ) {
				return new WP_Error( 'api_wcam_error', $response_body['data']['error'], $debug_data );
			}

			return new WP_Error( 'api_gvsam_error', $response_body['data']['error'], $debug_data );
		}

		return $response_body;
	}

	protected function build_url( $args = array(), $endpoint = '', $is_strict = true ) {
		if ( ! $this->api_url ) {
			return new WP_Error( 'api_url_missing_error', __( 'API URL is missing.', 'gplvault' ) );
		}

		$defaults = array(
			'api_key'  => $this->api_key,
			'instance' => $this->instance,
		);

		$base_url = $this->api_url;

		if ( $endpoint ) {
			$base_url = $this->get_endpoint( $endpoint );
			if ( ! $is_strict ) {
				return $base_url;
			}
			$defaults['subscription'] = $this->product_id;

			$main_api_args = wp_parse_args( $args, $defaults );

			return $base_url . '?' . http_build_query( $main_api_args, '', '&' );
		}

		$defaults['wc-api']     = 'wc-am-api';
		$defaults['object']     = $this->object;
		$defaults['product_id'] = $this->product_id;

		$wcam_args = wp_parse_args( $args, $defaults );

		// storing request args for debug log
		$this->request_action = isset( $wcam_args['wc_am_action'] ) ? sanitize_text_field( $wcam_args['wc_am_action'] ) : '';

		return $base_url . '?' . http_build_query( $wcam_args, '', '&' );
	}

	protected function get_endpoint( $endpoint ) {
		if ( ! $this->api_url ) {
			return new WP_Error( 'api_url_missing_error', __( 'API URL is missing.', 'gplvault' ) );
		}

		$url = trailingslashit( $this->api_url ) . trailingslashit( $this->api_namespace ) . $endpoint;

		return trailingslashit( $url );
	}

	public function set_api_key( $key ) {
		$this->api_key = $key;

		return $this;
	}

	public function set_product_id( $product_id ) {
		$this->product_id = $product_id;

		return $this;
	}

	public function ping() {
		return $this->request( $this->build_url( array(), 'ping', false ) );
	}

	public function status( $args = array() ) {
		$defaults = array(
			'wc_am_action' => 'status',
		);

		$args = wp_parse_args( $args, $defaults );

		$request_url = $this->build_url( $args );

		return $this->request( $request_url, array( 'method' => 'POST' ) );
	}

	public function activate( $args = array() ) {
		$defaults = array(
			'wc_am_action' => 'activate',
			'instance'     => $this->instance ?: $this->settings_manager->refresh_instance_id(), // phpcs:ignore WordPress.PHP.DisallowShortTernary.Found
		);

		$args = wp_parse_args( $args, $defaults );

		$request_url = $this->build_url( $args );

		return $this->request( $request_url, array( 'method' => 'POST' ) );
	}

	public function deactivate( $args = array() ) {
		$defaults = array(
			'wc_am_action' => 'deactivate',
		);

		$args = wp_parse_args( $args, $defaults );

		$request_url = $this->build_url( $args );

		return $this->request( $request_url, array( 'method' => 'POST' ) );
	}

	public function schema( $args = array(), $options = array() ) {
		$this->set_initials();

		$items = self::schema_payload();

		$defaults = array(
			'domain' => $this->domain(),
			'items'  => wp_json_encode( $items ),
		);

		$args = wp_parse_args( $args, $defaults );

		$url             = $this->build_url(
			$args,
			'schema'
		);
		$default_options = array(
			'method' => 'POST',
		);

		return $this->request( $url, wp_parse_args( $options, $default_options ) );
	}

	public function api_status( $args = array() ) {
		$url = $this->build_url( $args, 'status' );

		return $this->request( $url );
	}

	public function deferred_download( $product_id ) {
		if ( empty( $product_id ) ) {
			return '';
		}

		$args = array(
			'gv_delayed_download' => true,
			'gv_item_id'          => $product_id,
		);

		$admin_url = self_admin_url( 'admin.php?page=' . GPLVault_Admin::SLUG_SETTINGS );

		return add_query_arg( $args, esc_url( $admin_url ) );
	}

	public function download( $args ) {
		$this->set_initials();
		$defaults = array(
			'subscription' => $this->product_id,
			'domain'       => $this->object,
			'instance'     => $this->instance,
		);

		$args = wp_parse_args( $args, $defaults );

		$url = $this->build_url( $args, 'download' );

		$response = $this->request( $url );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		if ( isset( $response['package'] ) && ! empty( $response['package'] ) ) {
			return $response['package'];
		}

		return '';
	}

	public function client_schema( $args = array() ) {
		$this->set_initials();
		$defaults = array(
			'subscription' => $this->product_id,
			'domain'       => $this->object,
			'instance'     => $this->instance,
		);

		$args = wp_parse_args( $args, $defaults );
		$url  = $this->build_url( $args, 'client-schema' );
		return $this->request( $url );
	}

	public function api_key_exists() {
		$this->api_key = $this->settings_manager->get_api_key();

		return ! empty( $this->api_key );
	}

	protected function load_dependencies() {
		if ( ! function_exists( 'gv_settings_manager' ) ) {
			require_once GPLVault()->includes_path( '/gplvault-functions.php' );
		}

		$this->settings_manager = gv_settings_manager();
	}

	public function set_initials() {
		$this->object     = $this->domain();
		$this->api_key    = $this->settings_manager->get_api_key();
		$this->product_id = $this->settings_manager->get_product_id();
		$this->instance   = $this->settings_manager->get_instance_id( null );
		$this->api_url    = defined( 'GV_UPDATER_API_URL' ) ? trailingslashit( GV_UPDATER_API_URL ) : 'https://www.gplvault.com/';

		return $this;
	}

	public function set_instance( $instance ) {
		$this->instance = $instance;

		return $this;
	}

	public function domain() {
		return str_ireplace( array( 'http://', 'https://' ), '', home_url() );
	}

	public static function schema_payload() {
		$installed_plugins = GPLVault_Helper::all_plugins();
		unset( $installed_plugins[ GPLVault()->plugin_basename() ] );

		$plugins = array();
		foreach ( $installed_plugins as $plugin_file => $plugin_data ) {
			$plugins[ $plugin_file ] = $plugin_data['Version'];
		}

		$installed_themes = GPLVault_Helper::all_themes( false );
		$themes           = array();
		foreach ( $installed_themes as $dir => $theme ) {
			$themes[ $dir ] = $theme->get( 'Version' );
		}

		return array(
			'plugins' => $plugins,
			'themes'  => $themes,
		);
	}
}
