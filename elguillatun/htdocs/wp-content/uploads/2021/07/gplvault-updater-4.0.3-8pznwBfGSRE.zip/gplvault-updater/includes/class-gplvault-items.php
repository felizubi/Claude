<?php

defined( 'ABSPATH' ) || exit;

class GPLVault_Items {
	protected static $singleton;
	/**
	 * @var GPLVault_Hooks $eventEmitter
	 */
	protected $eventEmitter;

	/**
	 * @var GPLVault_Settings_Manager $settings
	 */
	protected $settings;

	/**
	 * @var GPLVault_API_Manager $api
	 */
	private $api;

	public static function instance() {
		return new static();
	}

	private function __construct() {
		include_once ABSPATH . 'wp-admin/includes/plugin.php';
		include_once ABSPATH . 'wp-admin/includes/theme.php';
	}

	private function __clone() { }

	public function __wakeup() { }

	public function init() {
		$this->settings = GPLVault_Settings_Manager::instance();
		$this->api      = GPLVault_API_Manager::instance();

		// Check for theme & plugin updates.
		if ( $this->settings->license_is_activated() ) {
			add_action( 'deleted_plugin', array( __CLASS__, 'deleted_plugin' ), 10, 2 );
		}

	}

	public static function deleted_plugin( $plugin_file, $is_deleted ) {
		if ( ! $is_deleted ) {
			return;
		}

		$gv_plugins = GPLVault_Helper::gv_plugins( false );

		if ( ! isset( $gv_plugins[ $plugin_file ] ) ) {
			return;
		}

		$gv_plugins_option = gv_settings_manager()->get_available_plugins();
		unset( $gv_plugins_option[ $plugin_file ] );
		gv_settings_manager()->update_plugins_catalog( $gv_plugins_option );
	}
}
