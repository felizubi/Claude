<?php

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WP_Ajax_Upgrader_Skin' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader-skins.php';
	//  require_once ABSPATH . 'wp-admin/includes/class-automatic-upgrader-skin.php';
	//  require_once ABSPATH . 'wp-admin/includes/class-wp-ajax-upgrader-skin.php';
}

class GPLVault_Ajax_Upgrader_Skin extends WP_Ajax_Upgrader_Skin {
	public function __construct( $args = array() ) { // phpcs:ignore Generic.CodeAnalysis.UselessOverridingMethod.Found
		parent::__construct( $args );
	}
}
