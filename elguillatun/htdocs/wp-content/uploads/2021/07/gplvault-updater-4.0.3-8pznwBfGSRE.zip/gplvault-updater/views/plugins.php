<?php
defined( 'ABSPATH' ) || exit;
if ( ! class_exists( 'GPLVault_Plugins_List_Table' ) ) {
	require_once GPLVault()->admin_path( '/class-gplvault-plugins-list-table.php' );
}
global $status, $page;

/** @var GPLVault_Settings_Manager $settings_manager    */
/** @var GPLVault_Admin $admin_manager */
$license_is_active = $settings_manager->license_is_activated();
if ( $license_is_active ) :
	GPLVault_Admin::gv_update_plugins();
	$list_table = new GPLVault_Plugins_List_Table();
	$pagenum    = $list_table->get_pagenum();
	$action     = $list_table->current_action(); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
	$plugin     = isset( $_REQUEST['plugin'] ) ? wp_unslash( $_REQUEST['plugin'] ) : ''; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited, WordPress.Security.NonceVerification.Recommended
	$s          = isset( $_REQUEST['s'] ) ? rawurlencode( wp_unslash( $_REQUEST['s'] ) ) : ''; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited, WordPress.Security.NonceVerification.Recommended

	// Clean up request URI from temporary args for screen options/paging uri's to work as expected.
	$query_args_to_remove = array(
		'error',
		'deleted',
		'activate',
		'activate-multi',
		'deactivate',
		'deactivate-multi',
		'enabled-auto-update',
		'disabled-auto-update',
		'enabled-auto-update-multi',
		'disabled-auto-update-multi',
		'_error_nonce',
	);

	$_SERVER['REQUEST_URI'] = remove_query_arg( $query_args_to_remove, $_SERVER['REQUEST_URI'] );

	$list_table->prepare_items();
endif;
?>
<div class="wrap gv-wrapper">
	<div class="gv-layout">
		<div class="gv-layout__primary">
			<div class="gv-layout__main gv-grids gv-grids__full">
				<?php if ( ! $license_is_active ) : ?>
				<div class="gv-admin-section">
					<div class="gv-admin-columns gv-grids gv-grids__columns-auto">
						<div class="gv-layout__columns">
							<div class="gv-card">
								<div class="gv-card__header">
									<h3 class="gv-card__title">
										<?php esc_html_e( 'Activate License', 'gplvault' ); ?></div>
									</h3>
								<div class="gv-card__body">
									<div class="gv-card__body-inner">
										<?php /* translator: %s: GPLVault Settings page URL */ ?>
										<h4>
										<?php
										printf(
											__( 'Please activate GPLVault Updater license to work with plugins. Activate License from %s page.', 'gplvault' ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
											'<a href="' . esc_url( $admin_manager->admin_links( 'settings' ) ) . '">' . esc_html__( 'Settings', 'gplvault' ) . '</a>'
										);
										?>
												</h4>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php else : ?>
				<div class="gv-admin-section">
					<div class="gv-section-header">
						<h2 class="gv-section-header__title"><?php esc_html_e( 'Plugins', 'gplvault' ); ?></h2>
						<hr role="presentation">
					</div>
					<div class="gv-admin__table">
						<?php $list_table->views(); ?>
						<form class="search-form search-plugins" method="get">
							<?php $list_table->search_box( __( 'Search GPLVault Plugins', 'gplvault' ), 'gv_plugin' ); ?>
						</form>

						<form method="post" id="gv_bulk_plugins_form" data-context="bulk_update_plugin">

							<input type="hidden" name="plugin_status" value="<?php echo esc_attr( $status ); ?>" />
							<input type="hidden" name="paged" value="<?php echo esc_attr( $page ); ?>" />

							<?php $list_table->display(); ?>
						</form>

						<span class="spinner"></span>
					</div>
					</div>
				</div> <!-- .gv-admin-section -->
				<?php endif; ?>
			</diov> <!-- .gv-layout__main -->
		</div>


	</div>
</div> <!-- .wrap -->

<?php
if ( ! function_exists( 'wp_print_request_filesystem_credentials_modal' ) ) {
	require_once ABSPATH . 'wp-admin/includes/file.php';
}
wp_print_request_filesystem_credentials_modal();
